import { defineConfig } from "vite";
import react from "@vitejs/plugin-react";

export default defineConfig({
  plugins: [react()],
  // GitHub Pages serves this site from /CurrentCurrents/, not the domain root,
  // so every asset URL needs that prefix. If you rename the repo, update this.
  base: "/CurrentCurrents/",
});
