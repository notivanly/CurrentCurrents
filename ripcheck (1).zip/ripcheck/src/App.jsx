import { useEffect, useState } from "react";
import Header from "./components/Header.jsx";
import BottomNav from "./components/BottomNav.jsx";
import MyBeach from "./pages/MyBeach.jsx";
import AllBeaches from "./pages/AllBeaches.jsx";
import Safety from "./pages/Safety.jsx";
import { BEACHES } from "./data/beaches.js";
import { fetchConditions } from "./lib/openMeteo.js";
import { calculateRisk } from "./lib/riskCalc.js";

export default function App() {
  const [tab, setTab] = useState("mybeach");
  const [beachesWithRisk, setBeachesWithRisk] = useState(BEACHES.map((beach) => ({ beach, risk: null })));
  const [loadingAll, setLoadingAll] = useState(true);

  // Load conditions for every seed beach once, so the map + All Beaches tab
  // can show risk levels without waiting on the user's own location first.
  useEffect(() => {
    let cancelled = false;

    async function loadAll() {
      const results = await Promise.all(
        BEACHES.map(async (beach) => {
          try {
            const conditions = await fetchConditions(beach.lat, beach.lon);
            const risk = calculateRisk({ conditions, shorelineFacing: beach.shorelineFacing });
            return { beach, risk, conditions };
          } catch {
            return { beach, risk: { level: "Unknown", factors: [], reasons: [] }, conditions: null };
          }
        })
      );
      if (!cancelled) {
        setBeachesWithRisk(results);
        setLoadingAll(false);
      }
    }

    loadAll();
    return () => {
      cancelled = true;
    };
  }, []);

  return (
    <div className="min-h-screen bg-slate-50">
      <Header />
      <main>
        {tab === "mybeach" && (
          <MyBeach onSeeAll={() => setTab("all")} allBeachesWithRisk={beachesWithRisk} />
        )}
        {tab === "all" && <AllBeaches beaches={beachesWithRisk} loading={loadingAll} />}
        {tab === "safety" && <Safety />}
      </main>
      <BottomNav active={tab} onChange={setTab} />
    </div>
  );
}
