import { RISK_STYLES } from "../lib/riskCalc.js";

export default function RiskCard({ beach, risk, conditions, distanceLabel }) {
  const style = RISK_STYLES[risk.level] ?? RISK_STYLES.Unknown;

  return (
    <div className="bg-white rounded-2xl border border-slate-200 shadow-sm p-5">
      <div className="flex items-start justify-between gap-3">
        <div>
          <p className="text-xs font-medium text-slate-500 uppercase tracking-wide">
            {distanceLabel ?? "Nearest monitored beach"}
          </p>
          <h2 className="text-lg font-bold text-ink mt-0.5">{beach.name}</h2>
          <p className="text-sm text-slate-500">{beach.state}</p>
        </div>
        <span
          className={`shrink-0 inline-flex items-center gap-1.5 rounded-full px-3 py-1.5 text-sm font-bold text-white ${style.bg}`}
        >
          {risk.level}
        </span>
      </div>

      {risk.level === "High" || risk.level === "Extreme" ? (
        <div className={`mt-4 rounded-xl ${style.light} ring-1 ${style.ring} px-4 py-3`}>
          <p className={`text-sm font-semibold ${style.text}`}>
            Elevated rip current risk. Stay out of the water unless a lifeguard confirms it's safe, and never swim alone.
          </p>
        </div>
      ) : null}

      {risk.level !== "Unknown" ? (
        <div className="mt-4 space-y-2">
          <p className="text-xs font-semibold text-slate-500 uppercase tracking-wide">What's driving this</p>
          <ul className="space-y-1.5">
            {risk.factors.map((f) => (
              <li key={f.label} className="flex items-center justify-between text-sm">
                <span className="text-slate-500">{f.label}</span>
                <span className="font-medium text-ink">{f.value}</span>
              </li>
            ))}
          </ul>
        </div>
      ) : (
        <p className="mt-4 text-sm text-slate-500">{risk.reasons[0]}</p>
      )}

      {conditions?.fetchedAt ? (
        <p className="mt-4 text-xs text-slate-400">
          Updated {new Date(conditions.fetchedAt).toLocaleTimeString([], { hour: "numeric", minute: "2-digit" })}
        </p>
      ) : null}
    </div>
  );
}
