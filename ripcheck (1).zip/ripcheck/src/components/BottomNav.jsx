const TABS = [
  { id: "mybeach", label: "My Beach", icon: "〜" },
  { id: "all", label: "All Beaches", icon: "☰" },
  { id: "safety", label: "Safety", icon: "⊛" },
];

export default function BottomNav({ active, onChange }) {
  return (
    <nav
      className="fixed bottom-0 left-0 right-0 bg-white border-t border-slate-200 flex justify-around items-stretch z-20"
      style={{ paddingBottom: "env(safe-area-inset-bottom)" }}
    >
      {TABS.map((tab) => {
        const isActive = active === tab.id;
        return (
          <button
            key={tab.id}
            onClick={() => onChange(tab.id)}
            className={`flex-1 flex flex-col items-center gap-1 py-2.5 text-xs font-medium transition-colors ${
              isActive ? "text-ink" : "text-slate-400"
            }`}
            aria-current={isActive ? "page" : undefined}
          >
            <span className="text-lg leading-none" aria-hidden="true">{tab.icon}</span>
            <span className={isActive ? "font-semibold" : ""}>{tab.label}</span>
          </button>
        );
      })}
    </nav>
  );
}
