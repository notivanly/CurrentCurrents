import { MapContainer, TileLayer, CircleMarker, Popup } from "react-leaflet";
import { RISK_STYLES } from "../lib/riskCalc.js";

const RISK_HEX = {
  Low: "#10b981",
  Moderate: "#f59e0b",
  High: "#f97316",
  Extreme: "#dc2626",
  Unknown: "#94a3b8",
};

export default function BeachMap({ beaches, userCoords, center, zoom = 5, height = 260 }) {
  const mapCenter = center ?? (userCoords ? [userCoords.lat, userCoords.lon] : [36.5, -100]);

  return (
    <div className="rounded-2xl overflow-hidden border border-slate-200 shadow-sm" style={{ height }}>
      <MapContainer center={mapCenter} zoom={zoom} scrollWheelZoom={false} style={{ height: "100%", width: "100%" }}>
        <TileLayer
          attribution='&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors'
          url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png"
        />
        {beaches.map(({ beach, risk }) => (
          <CircleMarker
            key={beach.id}
            center={[beach.lat, beach.lon]}
            radius={9}
            pathOptions={{
              color: "#0f172a",
              weight: 1.5,
              fillColor: RISK_HEX[risk?.level ?? "Unknown"],
              fillOpacity: 0.9,
            }}
          >
            <Popup>
              <strong>{beach.name}</strong>
              <br />
              Risk: {risk?.level ?? "Unknown"}
            </Popup>
          </CircleMarker>
        ))}
        {userCoords ? (
          <CircleMarker
            center={[userCoords.lat, userCoords.lon]}
            radius={7}
            pathOptions={{ color: "#1d4ed8", weight: 2, fillColor: "#60a5fa", fillOpacity: 1 }}
          >
            <Popup>You are here</Popup>
          </CircleMarker>
        ) : null}
      </MapContainer>
    </div>
  );
}
