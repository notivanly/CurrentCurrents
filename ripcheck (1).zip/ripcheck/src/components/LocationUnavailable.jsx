export default function LocationUnavailable({ onRetry, onSeeAll, message }) {
  return (
    <div className="bg-white rounded-2xl border border-slate-200 shadow-sm p-6 text-center">
      <h2 className="text-lg font-bold text-ink">Location unavailable</h2>
      <p className="text-sm text-slate-500 mt-1.5">
        {message ?? "Enable location access, or browse risk levels for every monitored beach."}
      </p>
      <div className="mt-5 space-y-2.5">
        <button
          onClick={onRetry}
          className="w-full bg-ink text-white font-semibold rounded-xl py-3 text-sm active:opacity-90"
        >
          Try again
        </button>
        <button
          onClick={onSeeAll}
          className="w-full bg-white text-ink font-semibold rounded-xl py-3 text-sm border border-slate-300 active:bg-slate-50"
        >
          See all beaches
        </button>
      </div>
    </div>
  );
}
