export default function Header() {
  return (
    <header className="bg-white border-b border-slate-200 px-4 py-3.5 flex items-center gap-2 sticky top-0 z-10">
      <span className="text-lg" aria-hidden="true">〜</span>
      <h1 className="text-lg font-bold tracking-tight text-ink">RipCheck</h1>
    </header>
  );
}
