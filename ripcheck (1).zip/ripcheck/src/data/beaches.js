// Seed list of monitored beaches.
// `shorelineFacing` = the compass direction the open water is in, relative to
// standing on the sand (i.e. the direction waves generally arrive FROM).
// It's used to judge whether wind/swell is blowing onshore (raises risk)
// or offshore (lowers risk). Approximate — refine per-beach over time.

export const BEACHES = [
  { id: "santa-monica-ca", name: "Santa Monica State Beach", state: "CA", lat: 34.0100, lon: -118.4962, shorelineFacing: 250 },
  { id: "huntington-ca", name: "Huntington City Beach", state: "CA", lat: 33.6553, lon: -118.0058, shorelineFacing: 235 },
  { id: "newport-ca", name: "Newport Beach", state: "CA", lat: 33.6060, lon: -117.9290, shorelineFacing: 220 },
  { id: "pacific-beach-ca", name: "Pacific Beach", state: "CA", lat: 32.7999, lon: -117.2553, shorelineFacing: 250 },
  { id: "santa-cruz-ca", name: "Santa Cruz Main Beach", state: "CA", lat: 36.9641, lon: -122.0183, shorelineFacing: 190 },
  { id: "cocoa-fl", name: "Cocoa Beach", state: "FL", lat: 28.3200, lon: -80.6076, shorelineFacing: 90 },
  { id: "clearwater-fl", name: "Clearwater Beach", state: "FL", lat: 27.9775, lon: -82.8272, shorelineFacing: 270 },
  { id: "miami-south-beach-fl", name: "South Beach", state: "FL", lat: 25.7826, lon: -80.1300, shorelineFacing: 100 },
  { id: "panama-city-fl", name: "Panama City Beach", state: "FL", lat: 30.1766, lon: -85.8055, shorelineFacing: 180 },
  { id: "myrtle-beach-sc", name: "Myrtle Beach", state: "SC", lat: 33.6891, lon: -78.8867, shorelineFacing: 100 },
  { id: "outer-banks-nc", name: "Nags Head", state: "NC", lat: 35.9573, lon: -75.6241, shorelineFacing: 90 },
  { id: "virginia-beach-va", name: "Virginia Beach", state: "VA", lat: 36.8529, lon: -75.9780, shorelineFacing: 100 },
  { id: "jones-beach-ny", name: "Jones Beach", state: "NY", lat: 40.5925, lon: -73.5119, shorelineFacing: 170 },
  { id: "cape-cod-ma", name: "Nauset Beach", state: "MA", lat: 41.7654, lon: -69.9563, shorelineFacing: 90 },
  { id: "galveston-tx", name: "Galveston Beach", state: "TX", lat: 29.2694, lon: -94.8480, shorelineFacing: 140 },
  { id: "waikiki-hi", name: "Waikiki Beach", state: "HI", lat: 21.2765, lon: -157.8276, shorelineFacing: 170 },
  { id: "seaside-or", name: "Seaside Beach", state: "OR", lat: 45.9932, lon: -123.9351, shorelineFacing: 260 },
  { id: "ocean-city-md", name: "Ocean City Beach", state: "MD", lat: 38.3365, lon: -75.0849, shorelineFacing: 100 },
];
