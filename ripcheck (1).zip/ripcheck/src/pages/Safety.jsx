const STEPS = [
  {
    title: "Stay calm",
    body: "A rip current pulls you away from shore, not underwater. Panicking wastes the energy you need to get back in.",
  },
  {
    title: "Don't fight it",
    body: "Swimming straight back toward the beach against the current will exhaust you. Rips are usually narrow.",
  },
  {
    title: "Swim parallel to shore",
    body: "Swim sideways, parallel to the beach, until you feel the pull ease — then angle back in toward the sand.",
  },
  {
    title: "Float if you can't swim out",
    body: "If you can't escape it, float or tread water. Most rip currents pull you out then release you past the breakers.",
  },
  {
    title: "Signal for help",
    body: "Wave your arm and call out to alert a lifeguard or people onshore. Don't be afraid to draw attention.",
  },
];

export default function Safety() {
  return (
    <div className="px-4 pt-4 pb-24 space-y-5 max-w-md mx-auto">
      <div className="bg-white rounded-2xl border border-slate-200 shadow-sm p-5">
        <h2 className="text-lg font-bold text-ink">If you're caught in a rip current</h2>
        <p className="text-sm text-slate-500 mt-1">
          Rip currents are the leading cause of lifeguard rescues in the US. Knowing these steps before you're in the water matters.
        </p>
      </div>

      <ol className="space-y-3">
        {STEPS.map((step, i) => (
          <li key={step.title} className="bg-white rounded-2xl border border-slate-200 shadow-sm p-4 flex gap-3">
            <span className="shrink-0 w-7 h-7 rounded-full bg-ink text-white text-sm font-bold flex items-center justify-center">
              {i + 1}
            </span>
            <div>
              <p className="font-semibold text-ink text-sm">{step.title}</p>
              <p className="text-sm text-slate-500 mt-0.5">{step.body}</p>
            </div>
          </li>
        ))}
      </ol>

      <div className="bg-white rounded-2xl border border-slate-200 shadow-sm p-5">
        <h3 className="font-semibold text-ink text-sm">If you see someone else caught in one</h3>
        <p className="text-sm text-slate-500 mt-1.5">
          Get help from a lifeguard first. If none is available, throw the person something that floats and call emergency services.
          Don't swim out to a struggling swimmer without a flotation device — rip currents are a leading cause of drowning among
          would-be rescuers too.
        </p>
      </div>

      <div className="bg-slate-100 rounded-2xl p-4">
        <p className="text-xs text-slate-500 leading-relaxed">
          RipCheck's risk estimates are not official forecasts. Always follow posted beach flags, lifeguard instructions, and
          official NOAA/NWS surf zone forecasts, which account for local factors this app cannot.
        </p>
      </div>
    </div>
  );
}
