import { RISK_STYLES } from "../lib/riskCalc.js";

export default function AllBeaches({ beaches, loading }) {
  return (
    <div className="px-4 pt-4 pb-24 max-w-md mx-auto space-y-3">
      <p className="text-sm text-slate-500 px-1">
        {loading ? "Loading current conditions…" : `${beaches.length} monitored beaches`}
      </p>
      {beaches.map(({ beach, risk }) => {
        const style = RISK_STYLES[risk?.level ?? "Unknown"];
        return (
          <div
            key={beach.id}
            className="bg-white rounded-2xl border border-slate-200 shadow-sm p-4 flex items-center justify-between gap-3"
          >
            <div>
              <p className="font-semibold text-ink text-sm">{beach.name}</p>
              <p className="text-xs text-slate-500">{beach.state}</p>
            </div>
            <span className={`shrink-0 inline-flex items-center rounded-full px-3 py-1 text-xs font-bold text-white ${style.bg}`}>
              {risk?.level ?? "…"}
            </span>
          </div>
        );
      })}
    </div>
  );
}
