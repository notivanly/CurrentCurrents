import { useEffect, useState } from "react";
import { useGeolocation, findNearestBeach, haversineMeters } from "../lib/geo.js";
import { fetchConditions } from "../lib/openMeteo.js";
import { calculateRisk } from "../lib/riskCalc.js";
import { BEACHES } from "../data/beaches.js";
import RiskCard from "../components/RiskCard.jsx";
import LocationUnavailable from "../components/LocationUnavailable.jsx";
import BeachMap from "../components/BeachMap.jsx";

function metersToLabel(m) {
  const miles = m / 1609.34;
  if (miles < 0.1) return "You're right here";
  if (miles < 10) return `${miles.toFixed(1)} mi away`;
  return `${Math.round(miles)} mi away`;
}

export default function MyBeach({ onSeeAll, allBeachesWithRisk }) {
  const { status, coords, error, retry } = useGeolocation();
  const [nearest, setNearest] = useState(null);
  const [conditions, setConditions] = useState(null);
  const [risk, setRisk] = useState(null);
  const [loadingConditions, setLoadingConditions] = useState(false);

  useEffect(() => {
    if (status !== "success" || !coords) return;
    const match = findNearestBeach(coords.lat, coords.lon);
    setNearest(match);

    if (!match.beach) return;
    setLoadingConditions(true);
    fetchConditions(match.beach.lat, match.beach.lon)
      .then((c) => {
        setConditions(c);
        setRisk(calculateRisk({ conditions: c, shorelineFacing: match.beach.shorelineFacing }));
      })
      .finally(() => setLoadingConditions(false));
  }, [status, coords]);

  if (status === "loading" || status === "idle") {
    return (
      <div className="px-4 pt-6 max-w-md mx-auto">
        <div className="bg-white rounded-2xl border border-slate-200 shadow-sm p-6 text-center text-sm text-slate-500">
          Finding your location…
        </div>
      </div>
    );
  }

  if (status === "error" || status === "unsupported") {
    return (
      <div className="px-4 pt-6 pb-24 max-w-md mx-auto space-y-4">
        <LocationUnavailable onRetry={retry} onSeeAll={onSeeAll} message={error} />
        <BeachMap beaches={allBeachesWithRisk} zoom={4} />
      </div>
    );
  }

  if (!nearest?.isNearBeach) {
    return (
      <div className="px-4 pt-6 pb-24 max-w-md mx-auto space-y-4">
        <LocationUnavailable
          onRetry={retry}
          onSeeAll={onSeeAll}
          message={
            nearest?.beach
              ? `You're not near a monitored beach. Closest is ${nearest.beach.name}, about ${metersToLabel(nearest.distanceM)}.`
              : "You're not near a monitored beach right now."
          }
        />
        <BeachMap beaches={allBeachesWithRisk} userCoords={coords} zoom={4} />
      </div>
    );
  }

  return (
    <div className="px-4 pt-4 pb-24 max-w-md mx-auto space-y-4">
      {loadingConditions || !risk ? (
        <div className="bg-white rounded-2xl border border-slate-200 shadow-sm p-6 text-center text-sm text-slate-500">
          Checking current conditions at {nearest.beach.name}…
        </div>
      ) : (
        <RiskCard
          beach={nearest.beach}
          risk={risk}
          conditions={conditions}
          distanceLabel={metersToLabel(nearest.distanceM)}
        />
      )}
      <BeachMap
        beaches={allBeachesWithRisk}
        userCoords={coords}
        center={[nearest.beach.lat, nearest.beach.lon]}
        zoom={9}
      />
    </div>
  );
}
