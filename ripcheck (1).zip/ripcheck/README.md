# RipCheck

A rip current risk estimator. It checks the user's location, matches it to a
monitored beach, pulls live wind/wave data, and shows a Low/Moderate/High/Extreme
risk estimate along with a rip-current safety guide.

**This is a risk estimate, not an official forecast.** It's meant to encourage
caution and awareness, not replace posted beach flags, lifeguards, or NOAA/NWS
surf zone forecasts. See the disclaimer in the Safety tab.

## Stack

- React 18 + Vite
- Tailwind CSS
- Leaflet / react-leaflet for the map
- [Open-Meteo](https://open-meteo.com) — free, no-API-key marine & weather data

## Run it locally

```bash
npm install
npm run dev
```

Then open the local URL Vite prints (usually `http://localhost:5173`).

## Push this to GitHub

From inside this folder:

```bash
git init
git add .
git commit -m "Initial commit"
git branch -M main
git remote add origin https://github.com/YOUR_USERNAME/YOUR_REPO.git
git push -u origin main
```

(Create an empty repo on GitHub first, without a README, then copy its URL
into the `remote add` command above.)

## Deploy

Any static host works since this builds to plain HTML/CSS/JS:

- **Vercel**: import the GitHub repo at vercel.com/new — it auto-detects Vite.
- **Netlify**: "Add new site" → "Import an existing project" → point at the repo.
  Build command: `npm run build`, publish directory: `dist`.
- **GitHub Pages**: run `npm run build`, then deploy the `dist/` folder using
  a `gh-pages` action or the `gh-pages` npm package.

## Project structure

```
src/
  data/beaches.js      Seed list of monitored beaches (lat/lon + shoreline angle)
  lib/openMeteo.js      Fetches wave + wind data from Open-Meteo
  lib/riskCalc.js       Turns conditions into a Low/Moderate/High/Extreme score
  lib/geo.js            Browser geolocation + nearest-beach matching
  components/           RiskCard, BeachMap, BottomNav, Header, LocationUnavailable
  pages/                MyBeach, AllBeaches, Safety
  App.jsx                Tab state + loads risk for every seed beach
```

## Extending it

- **Add beaches**: append entries to `src/data/beaches.js`. `shorelineFacing`
  is the compass bearing the open water lies in — used to judge whether wind
  and swell are blowing onshore (raises risk) or offshore (lowers it). Eyeball
  it from a map; it doesn't need to be exact.
- **Tune the risk formula**: all of the scoring logic lives in
  `src/lib/riskCalc.js` in one place, with comments on why each factor is
  weighted the way it is.
- **Swap in NOAA data**: Open-Meteo's marine model is a good free starting
  point, but NOAA/NWS publishes its own localized rip current risk statements
  per coastal office (not a single unified API — more fragmented). Worth
  layering in later for US beaches specifically, or linking out to the local
  NWS forecast per beach in the meantime.
- **Background alerts**: this version only checks location in the foreground
  (when the tab is open), which is simpler and better for battery/privacy.
  A push-notification version would need a service worker and a backend job
  to re-check risk periodically — a bigger lift, worth doing once the core
  risk logic is solid.
